from django.shortcuts import render
from .models import Artist, Event

def index(request):
    kai, _ = Artist.objects.get_or_create(name="Kai Angel")
    events = Event.objects.all().order_by('year')
    return render(request, 'index.html', {'kai': kai, 'events': events})