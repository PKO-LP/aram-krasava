from django.db import models


class Artist(models.Model):
    name = models.CharField(max_length=50, default="Kai Angel")
    real_name = models.CharField(max_length=100, default="Дмитрий Ицков")
    age = models.IntegerField(default=28)
    hometown = models.CharField(max_length=100, default="Москва")
    photo = models.ImageField(upload_to='artists/', null=True, blank=True)
    bio = models.TextField()


class Event(models.Model):
    year = models.CharField(max_length=10)
    description = models.CharField(max_length=255)

    def __str__(self):
        return f"{self.year} - {self.description}"